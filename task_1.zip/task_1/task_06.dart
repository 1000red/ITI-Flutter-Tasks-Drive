class Todo {
  int id;
  String title;
  bool isDone;

  Todo(this.id, this.title, this.isDone);

  void toggle() {
    isDone = !isDone;
  }
}
