class Book {
  String? title;
  String? author;
  late int pages;

  Book(t, a, p) {
    this.title = t;
    this.author = a;
    this.pages = p;
  }

  bool isLong() {
    return pages >= 300;
  }

  // dynamic long_ones(List arr) {
  //   int x = 0;

  //   for (int i = 0; i < 5; i++) {
  //     if (x < i) {
  //       x = i;
  //     }
  //   }
  //   print();
  // }
}
