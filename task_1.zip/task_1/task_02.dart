class Rectangle {
  late double width;
  late double height;

  Rectangle(w, h) {
    this.width = w;
    this.height = h;
  }

  double area() {
    return width * height;
  }
}
