class BankAccount {
  String? owner;
  late double balance;

  BankAccount(o, b) {
    this.owner = o;
    this.balance = b;
  }

  void deposit(double amount) {
    if (amount < 0) {
      print("no negative amounts, no overdraft");
    }

    balance += amount;
    print("${owner} balance: ${balance}");
  }

  void withdraw(double amount) {
    if (amount <= 0) {
      print("Withdraw amount must be positive.");
    }
    if (amount > balance) {
      print("Insufficient funds. Cannot withdraw ${amount}.");
    }
    balance -= amount;
    print("${owner} balance: ${balance}");
  }
}
