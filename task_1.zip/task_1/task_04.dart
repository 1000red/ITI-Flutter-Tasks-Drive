class Counter {
  int num = 0;

  increment() {
    num++;
  }

  decrement() {
    num--;
  }

  reset() {
    num = 0;
  }

  int get() {
    return num;
  }

  int get value {
    return num;
  }
}
