class Logger {
  void log(String message) {
    var now = DateTime.now();
    print(now);
  }
}
