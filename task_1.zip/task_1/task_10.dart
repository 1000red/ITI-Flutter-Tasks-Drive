class Product {
  String name;
  double price;
  double discountPercent;

  Product(this.name, this.price, this.discountPercent);

  double finalPrice() {
    return price * (1 - discountPercent / 100);
  }
}
