import 'dart:math';

class Point2D {
  double x;
  double y;

  Point2D(this.x, this.y);

  double distanceTo(Point2D other) {
    double dx = other.x - x;
    double dy = other.y - y;
    return sqrt(dx * dx + dy * dy);
  }
}
