class Person {
  String? name;
  int? age;

  Person(n, a) {
    this.name = n;
    this.age = a;
  }

  String describe() {
    return "{name: $name, age: $age}";
  }
}
